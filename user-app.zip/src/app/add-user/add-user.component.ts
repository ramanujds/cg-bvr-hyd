import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { UserApiService } from '../user-api.service';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  constructor(private userApiService:UserApiService) { }
  user:User;
  ngOnInit(): void {
    this.user=new User();
  }

  addUser(){
    this.userApiService.addUser(this.user).subscribe(
      (success)=>{
        alert("User Added");
      },
      (error)=>{
        alert("Error:User Not Added");
      }
    )
  }



}
