export class Student{
    constructor(public sName:string,public age:number,public city:string){}
}