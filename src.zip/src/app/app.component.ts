import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from './student';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'another-app';
  user:any;
  filteredStatus='';
  afterSearch:Array<Student>=new Array(); 
  studentList:Array<Student>;
  constructor(private httpClient:HttpClient){

  }
  ngOnInit():void{
    let students=this.httpClient.get("/assets/students.json");

    students.subscribe(
      (students:Array<Student>)=>{
        this.studentList=students;
        console.log(students);
        this.afterSearch=students;
      }
    );

  }
  showData(userName:string){
    let userData= this.httpClient.get("https://api.github.com/users/"+userName);
    userData.subscribe(
      (data)=>
      {
        this.user=data;
      }
    );

  }
  searchByName(searchText:string):void{
    let sts:Array<Student>=this.studentList.
              filter((s)=>s.sName.toLowerCase().includes(
                                searchText.toLowerCase()));

    if(searchText==''){
      this.afterSearch=this.studentList;
    }
    else{
      this.afterSearch=sts;
      }
      
  }
}
