import { Component, OnInit } from '@angular/core';
import { MovieInfoService } from '../movie-info.service';
import { Route } from '@angular/compiler/src/core';
import { Routes, Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private movieInfoService:MovieInfoService, private route:Router) { }
  searchTxt=0;
  ngOnInit(): void {
  }

  searchMovie(){
   this.route.navigate(["/view-movie/id/"+this.searchTxt]);
  }
}
