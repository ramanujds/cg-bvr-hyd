export class Movie{
    id:number;
	rating:number;
	movieName:string;
    ratingServicePort:number;
     catelogServicePort:number;
}