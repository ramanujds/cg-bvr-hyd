import { Component, OnInit } from '@angular/core';
import { MovieInfoService } from '../movie-info.service';
import { ActivatedRoute } from '@angular/router';
import { Movie } from '../Movie';

@Component({
  selector: 'app-view-movie',
  templateUrl: './view-movie.component.html',
  styleUrls: ['./view-movie.component.css']
})
export class ViewMovieComponent implements OnInit {

  constructor(private movieInfoService: MovieInfoService, private route: ActivatedRoute) { }

  searchId = 0;
  movie: Movie;
  ngOnInit(): void {


    this.route.params.subscribe(param => {
      this.searchId = param["id"];


      this.movieInfoService.getAllMovieById(this.searchId).subscribe(

        (response) => {
          this.movie = response;
          this.movieInfoService.movie=this.movie;
        },
        (error) => {
          alert("No Movie found with id = " + this.searchId);
        }
      );
    })

  }

}
