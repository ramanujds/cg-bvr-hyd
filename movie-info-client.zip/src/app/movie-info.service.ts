import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Movie } from './Movie';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieInfoService {

  movie:Movie;
  constructor(private movieClient:HttpClient) { }

  private baseUrl="http://localhost:8100/info";

  addMovie(movie:Movie):Observable<Movie>{
      return this.movieClient.post<Movie>(this.baseUrl+"/add",movie);
  }

  getAllMovies():Observable<Array<Movie>>{
    return this.movieClient.get<Array<Movie>>(this.baseUrl+"/all");
  }

  getAllMovieById(id:number):Observable<Movie>{
    return this.movieClient.get<Movie>(this.baseUrl+"/id/"+id);
  }



}
