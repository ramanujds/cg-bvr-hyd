import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { ViewMovieComponent } from './view-movie/view-movie.component';
import { MovieListComponent } from './movie-list/movie-list.component';


const routes: Routes = [
  {
    path:"add-movie", component:AddMovieComponent
  },
  {
    path:"view-movie/id/:id", component:ViewMovieComponent
  },
  {
    path:"movie-list", component:MovieListComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
