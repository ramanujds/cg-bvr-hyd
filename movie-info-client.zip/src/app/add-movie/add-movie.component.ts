import { Component, OnInit } from '@angular/core';
import { Movie } from '../Movie';
import { MovieInfoService } from '../movie-info.service';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {


  constructor(private movieInfoService:MovieInfoService) { }

  movie:Movie;

  ngOnInit(): void {
    this.movie=new Movie();
  }
  addMovie(){
    this.movieInfoService.addMovie(this.movie).subscribe(
      (success)=>{
        alert("Movie Added");
      },
      (error)=>
      {
        alert("Failed to Add Movie");
      }
    )
  }

}
