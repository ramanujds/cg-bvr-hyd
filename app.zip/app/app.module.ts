import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DateComponent } from './date/date.component';
import { HeaderComponent } from './header/header.component';
import { NavComponent } from './nav/nav.component';
import { MainComponent } from './main/main.component';
import { FooterComponent } from './footer/footer.component';
import { from } from 'rxjs';
import { UpdateComponent } from './update/update.component';
import { TestService } from './test.service';

@NgModule({
  declarations: [
    AppComponent,
    DateComponent,
    HeaderComponent,
    NavComponent,
    MainComponent,
    FooterComponent,
    UpdateComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
   
  ],
  providers: [TestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
