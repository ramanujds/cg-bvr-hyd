import { Injectable } from '@angular/core';
import { Student } from './main/Student';

@Injectable({
  providedIn: 'root'
})
export class StudentDataService {

  students:Array<Student>=new Array();
  constructor() { }
}
