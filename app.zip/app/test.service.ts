import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  x=0;
  show(){
    console.log(" Test Service Executed ! x = "+this.x);
  }


  constructor() { }
}
