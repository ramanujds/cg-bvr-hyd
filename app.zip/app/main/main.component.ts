import { Component, OnInit } from '@angular/core';
import { Student } from './Student';
import { Router } from '@angular/router';
import { StudentDataService } from '../student-data.service';



@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {


  constructor(private router:Router, private studentService:StudentDataService) { }
  public update=false;
  students:Array<Student>=this.studentService.students;
  currentIndex:number;
  public sName:string;
  age:number;
  ngOnInit(): void {
    
  }
  addStudent(){
    this.students.push(new Student(this.sName,this.age));
    
  }
  deleteStudent(index:number){
    this.update=false;
    if(confirm("Sure to delete?")){
    this.students.splice(index,1);
    alert("Deleted");
    }
    
  }

  processUpdate(index:number){
    this.router.navigate(["/"+index]);
    // this.currentIndex=index;
    // this.sName=this.students[index].sName;
    // this.age=this.students[index].age;
    // this.update=true;

  }
  
  
}
