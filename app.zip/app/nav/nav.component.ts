import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TestService } from '../test.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  
  constructor(private ts:TestService) { }
 ngOnInit(): void {
  }
  

  callService(){
    this.ts.x=20;
    this.ts.show();
    
  }
}
