import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { StudentDataService } from '../student-data.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  private itemIndex:number;
  constructor(private route:ActivatedRoute, private studentService:StudentDataService) { }

  sName:string;
  age:number;

  ngOnInit() {
    this.itemIndex=this.route.snapshot.params['index'];
    this.sName=this.studentService.students[this.itemIndex].sName;
    this.age=this.studentService.students[this.itemIndex].age;




    
    this.route.params.subscribe((params:Params)=>{
      this.itemIndex=params['index'];
    }
    );
    
    }
    updateStudent(){
      this.studentService.students[this.itemIndex].sName=this.sName;
      this.studentService.students[this.itemIndex].age=this.age;
      alert("Student Updated");
      }


}
