import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Book } from '../book';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  id:number;
  title:string;
  author:string;
  year:number;
  index:number;
  constructor(public dataService:DataService,private activeRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.activeRoute.params.subscribe(
      (param)=>{
        this.index=param['index'];
        let book:Book =this.dataService.bookData[this.index];
        this.id=book.id;
        this.title=book.title;
        this.author=book.author;
        this.year=book.year;
      }
    );
    

  }

  updateBook(){
    this.dataService.bookData[this.index]=new Book(this.id,this.title,this.year,this.author);
    alert("Book Updated");
  }

}
