import { Component, OnInit } from '@angular/core';
import {DataService} from '../data.service';
import { Book } from '../book';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';
import { templateJitUrl } from '@angular/compiler';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
books:Book[];
  constructor(private dataService:DataService, private router:Router) { }

  ngOnInit(): void {
    this.books=this.dataService.bookData;
  }

  deleteBook(i:number){
    this.dataService.bookData.splice(i,1);
  }
  updateBook(i:number){
    this.router.navigate(["/update/"+i]);
  }
}
