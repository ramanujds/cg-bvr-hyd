export class Book{
    constructor(public id:number,public title:string,public year:number,public author:string){
        
    }
}