import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  public bookData:Book[];
  
  constructor(private httpClient:HttpClient) {
    httpClient.get("/assets/data.json").subscribe(
        (books:Book[])=>{
            this.bookData=books;
            console.log(this.bookData);
        }
        
    );
   }
}
