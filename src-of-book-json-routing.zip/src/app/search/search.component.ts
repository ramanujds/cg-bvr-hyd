import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { DataService } from '../data.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  books:Book[];
searchedBooks:Book[];
  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.books=this.dataService.bookData;
  }

  searchBook(title:string){
    this.searchedBooks=
    this.books.filter((b)=>b.title.toLowerCase().startsWith(title.toLowerCase()));
  }

}
